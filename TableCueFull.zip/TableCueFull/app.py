from flask import Flask, render_template, request, redirect, session, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from db import db
from models import Restaurant, Reservation
import re

app = Flask(__name__)
app.secret_key = "tablecue_secret"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tablecue.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "tablecue123"

with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        url = request.form['url'].lower()

        if not re.match("^[a-zA-Z0-9]+$", url):
            flash("URL must be alphanumeric with no spaces or symbols.", "danger")
            return redirect(url_for('register'))

        if Restaurant.query.filter_by(url=url).first():
            flash("This URL is already taken.", "danger")
            return redirect(url_for('register'))

        new_restaurant = Restaurant(name=name, email=email, password=password, url=url)
        db.session.add(new_restaurant)
        db.session.commit()
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for('login'))

    return render_template("register.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Restaurant.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session['restaurant_id'] = user.id
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials", "danger")
    return render_template("login.html")

@app.route('/dashboard')
def dashboard():
    if 'restaurant_id' not in session:
        return redirect(url_for('login'))
    restaurant = Restaurant.query.get(session['restaurant_id'])
    queue = Reservation.query.filter_by(restaurant_id=restaurant.id).all()
    return render_template("dashboard.html", restaurant=restaurant, queue=queue)

@app.route('/<restro>/reserve', methods=['GET', 'POST'])
def reserve(restro):
    restaurant = Restaurant.query.filter_by(url=restro).first()
    if not restaurant:
        return "Invalid restaurant URL", 404
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        people = int(request.form['people'])
        special = request.form['special']

        new_reservation = Reservation(name=name, phone=phone, people=people,
                                      special=special, restaurant_id=restaurant.id)
        db.session.add(new_reservation)
        db.session.commit()

        token_number = new_reservation.id
        return render_template("success.html", token=token_number, restro=restro)
    return render_template("reserve.html", restro=restro)

@app.route('/<restro>/queue')
def public_queue(restro):
    restaurant = Restaurant.query.filter_by(url=restro).first()
    if not restaurant:
        return "Invalid restaurant URL", 404
    queue = Reservation.query.filter_by(restaurant_id=restaurant.id).all()
    return render_template("queue_status.html", restro=restro, queue=queue)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid admin credentials", "danger")
    return render_template("admin.html")

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin'))
    restaurants = Restaurant.query.all()
    return render_template("admin_dashboard.html", restaurants=restaurants)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80,debug=True)
