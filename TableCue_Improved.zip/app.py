# Flask app entrypoint with Bootstrap and hardcoded admin
