
from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
import re

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../shared/tablecue.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    url_slug = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    restaurant_url = db.Column(db.String(50), db.ForeignKey('restaurant.url_slug'), nullable=False)
    customer_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    people_count = db.Column(db.Integer, nullable=False)
    special_request = db.Column(db.String(200))
    status = db.Column(db.String(20), default='queued')  # queued, seated, cancelled

@app.route('/restaurant/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        slug = request.form['url_slug']
        password = request.form['password']

        if not re.match("^[a-zA-Z0-9_-]+$", slug):
            return "URL must be alphanumeric (no spaces or special characters)"

        if Restaurant.query.filter_by(url_slug=slug).first():
            return "Restaurant URL already in use."

        hashed = generate_password_hash(password)
        rest = Restaurant(name=name, email=email, phone=phone, address=address, url_slug=slug, password_hash=hashed)
        db.session.add(rest)
        db.session.commit()
        return redirect('/restaurant/login')

    return render_template("restaurant_register.html")

@app.route('/restaurant/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        slug = request.form['url_slug']
        password = request.form['password']
        rest = Restaurant.query.filter_by(url_slug=slug).first()

        if not rest or not check_password_hash(rest.password_hash, password):
            return "Invalid login credentials."

        session['restaurant_slug'] = slug
        return redirect('/restaurant/dashboard')

    return render_template('restaurant_login.html')

@app.route('/restaurant/dashboard')
def dashboard():
    if 'restaurant_slug' not in session:
        return redirect('/restaurant/login')

    reservations = Reservation.query.filter_by(restaurant_url=session['restaurant_slug']).all()
    return render_template('dashboard.html', reservations=reservations, slug=session['restaurant_slug'])

@app.route('/restaurant/logout')
def logout():
    session.clear()
    return redirect('/restaurant/login')

@app.route('/restaurant/<restroname>/reserve', methods=['GET', 'POST'])
def reserve(restroname):
    rest = Restaurant.query.filter_by(url_slug=restroname).first()
    if not rest:
        return "Restaurant not found."

    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        people = int(request.form['people'])
        special = request.form['special']

        reservation = Reservation(
            restaurant_url=restroname,
            customer_name=name,
            phone=phone,
            people_count=people,
            special_request=special
        )
        db.session.add(reservation)
        db.session.commit()
        return render_template("thanks.html", name=name)

    return render_template("reserve_form.html", restroname=restroname)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000)
