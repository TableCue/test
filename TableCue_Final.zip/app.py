
from flask import Flask, render_template, request, redirect, session, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import re

app = Flask(__name__)
app.secret_key = "tablecue_secret"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tablecue.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

from models import Restaurant, Reservation, Admin
with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        url = request.form['url'].lower()
        if not re.match("^[a-zA-Z0-9]+$", url):
            flash("URL must be alphanumeric without spaces or special characters.")
            return redirect('/register')
        if Restaurant.query.filter_by(url=url).first():
            flash("URL already taken.")
            return redirect('/register')
        new_restaurant = Restaurant(name=name, email=email, password=password, url=url)
        db.session.add(new_restaurant)
        db.session.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Restaurant.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['restaurant_id'] = user.id
            return redirect('/dashboard')
        else:
            flash("Invalid login")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'restaurant_id' not in session:
        return redirect('/login')
    restaurant = Restaurant.query.get(session['restaurant_id'])
    reservations = Reservation.query.filter_by(restaurant_id=restaurant.id).all()
    return render_template('dashboard.html', reservations=reservations, restaurant=restaurant)

@app.route('/<restaurant_url>/reserve', methods=['GET', 'POST'])
def reserve(restaurant_url):
    restaurant = Restaurant.query.filter_by(url=restaurant_url).first()
    if not restaurant:
        return "Invalid restaurant URL", 404
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        people = int(request.form['people'])
        special = request.form['special']
        reservation = Reservation(name=name, phone=phone, people=people, special=special, restaurant_id=restaurant.id)
        db.session.add(reservation)
        db.session.commit()
        return render_template("reserve.html", restaurant=restaurant, success=True)
    return render_template("reserve.html", restaurant=restaurant)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password, password):
            session['admin'] = True
            return redirect('/admin/dashboard')
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect('/admin')
    restaurants = Restaurant.query.all()
    return render_template('admin_dashboard.html', restaurants=restaurants)

if __name__ == "__main__":
    app.run(debug=True)
