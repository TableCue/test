from flask import Flask, render_template, request
from models import db, Reservation, Restaurant

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///reservation.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

@app.route('/restaurant/<restroname>/reserve', methods=['GET', 'POST'])
def reserve(restroname):
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        people = int(request.form['people'])
        special = request.form['special']

        reservation = Reservation(
            restaurant_name=restroname,
            customer_name=name,
            phone=phone,
            people_count=people,
            special_request=special
        )
        db.session.add(reservation)
        db.session.commit()

        return f"<h3>Thank you {name}, your reservation at {restroname} is confirmed!</h3>"

    return render_template("reserve_form.html", restroname=restroname)

@app.route('/restaurant/register', methods=['GET', 'POST'])
def register_restaurant():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        capacity = request.form['capacity']

        existing = Restaurant.query.filter_by(name=name).first()
        if existing:
            return f"<h3 style='color:red'>Restaurant '{name}' already registered.</h3>"

        restro = Restaurant(
            name=name,
            email=email,
            phone=phone,
            address=address,
            capacity=int(capacity)
        )
        db.session.add(restro)
        db.session.commit()

        return f"<h3 style='color:green'>Restaurant '{name}' registered successfully!</h3>"

    return render_template("restaurant_register.html")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000)
